select
    *
from {{source('tutorial', 'customers_seed')}}
