select
    *
from {{source('tutorial', 'countries_seed')}}
