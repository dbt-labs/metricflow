"""Contains logging-related classes / functions.

Named with the 'mf_' prefix to avoid collision with the built-in module.
"""
