"""Example test cases that may be helpful to new developers."""
