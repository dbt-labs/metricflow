from __future__ import annotations


class InvalidQueryException(Exception):
    """Exception thrown when there is an error with the parameters to a MF query."""

    pass
