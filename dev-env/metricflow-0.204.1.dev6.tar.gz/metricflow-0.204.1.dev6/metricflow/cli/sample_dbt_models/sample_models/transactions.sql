select
    *
from {{source('tutorial', 'transactions_seed')}}
