"""File containing constants used by CLI."""

# Display Setting Constants
from __future__ import annotations

MAX_LIST_OBJECT_ELEMENTS = 5
DEFAULT_RESULT_DECIMAL_PLACES = 2
